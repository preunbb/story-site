---
title: "Teen Bitch Neighbor: Chapter 3"
author: SoleMann
posted: "April 3, 2021 at 11:34am"
source: "https://kickedinthegroin.ning.com/group/bb-storytellers/forum/topics/teen-bitch-neighbor-chapter-3"
slug: teen-bitch-neighbor-chapter-3
---
# Teen Bitch Neighbor 

**Chapter 3: Taking a Break** 

**By: SoleMann** 

I crawled my way into the bathroom as quickly as I could and locked the door behind me. I removed my sweats and underpants, and cleaned myself off as best I could. I then closed the lid on the toilet and sat for a mount to rest my weary knees. As I rubbed my knees to try and get some of the stiffness out of them, I noticed that they were really red and sore from what they had gone through today. On top up that I could see bruises starting to form as a result of Alexis’ weight being on my back as they slammed into the ground.

Once my knees felt strong enough to stand on again, I got up and put my sweat pants back on. Now the only problem was what to do with my cum soaked underpants. I thought of hiding them in the cabinet under the sink, but they would be to easily found, if I didn’t get the chance to get them before I left. I glanced around the room and saw a clothes hamper in the corner by the sink. There was no way I could just hide it among their dirty clothes, but I could hide it under the hamper, I doubt they’d ever find it there.

I went over to the hamper, lifted it up a little, and stuffed my underpants in the small enclosed area underneath it. Even though I knew they had just moved in today, I couldn’t resist opening the hamper up to see if there might be a nice fragrant pair of dirty sox inside. Since both Alexis and Jenna were total knockouts, with lovely feet, it didn’t really mater whose sox I might find. Unfortunately, as I expected, it was empty but thoughts that I might one day have a treasure to take home with me put a little smile on my face.

I opened the bathroom door and went back into the kitchen. But when I got there, Alexis was nowhere to be seen. I then heard voices coming from the living room, so I head in to see what was up. As I entered the room, Jenna was sitting on a chair just to the left of where Alexis was sitting on a loveseat.

“Oh there you finally are,” Jenna said. “We’re just taking a little break and talking about plans for our new house.”

“Come sit down and join us,” Alexis said, as she motioned with her eyes for me to sit on the floor at her feet.

This was perfect, not only was that the first place I thought of taking a seat, but Alexis seemed to want me to sit there as well. I went over to where she was sitting, and slowly sat down on the floor with Alexis just to my right. Now I had a great view of both Alexis’ and Jenna’s lovely feet.

“You don’t have to sit on the floor,” Jenna said. “Alexis can scoot over and make room for you.”

Not wanting to lose my view or to upset Alexis, I replied, “No that’s ok, I’m fine here. I can see both of you while we’re talking, plus I can stretch out and relax a little.”

With that, I rested back on my elbows and stretched my legs out in front of me. It then hit me that I had no underpants on, so I bent my right knee up. The last thing I needed was for Jenna to notice, and with me being at the lovely feet of these to beautiful girls, I’m sure it wouldn’t be long before signs of arousal would show through my thin sweats.

“That’s perfect,” Alexis said.

She then lifted her left leg and rested her heel on my right knee. She followed up by crossing her right leg over her left at her ankles. When she did this, she hit a really tender spot on my sore bruised knee, and I winced a little. Alexis must have noticed, cause she got that devilish grin again, and started to sway her right foot. This swaying motion traveled through to her left foot, and it now felt like she was grinding her heel into my already damaged knee. In spite of the torment she was causing me, the site of her soft supple soles waving in front of me, caused a tent to form in my sweat pants.

“Alexis!” Jenna exclaimed. “I’m sorry, please excuse my daughter. We were just discussing how nice it would be to get a coffee table to set our drinks and rest our feet up on. I guess since you were in about the same place we were thinking of putting it, Alexis just took the liberty of seeing how it would be.”

“No problem,” I stammered out, “that’s fine with me.”

“Really? Then would you mind flipping over and getting on all fours, so we can get a better idea of how it will be.” Alexis said while lightly pushing on my right knee to get me to roll over.

Is she kidding? Not that I wasn’t enjoying the view, but her tormenting my knee was starting to become unbearable. I slowly rolled to my left, trying my best to hide the huge tent in my sweats. The whole time Alexis kept nudging me over with her feet. Once I was on my hands and knees again, I slid a little closer to her and she immediately put her feet on my back.

As I lowered my head to let I just hang down, I could see my manhood pointing back at me. Thank god Jenna was behind me and couldn’t see my engorged member bobbing in my loose sweats. Although I had no doubt that Alexis could see it clearly from her angle.

“Ah, that’s better,” Alexis said.

“Not really,” Jenna replied. “I can’t reach from over here.”

“In that case, back up a little,” Alexis said, as she took her right foot off my back, and reached under me to nudge me back a little.

From Jenna’s point of view, I’m sure it looked like Alexis was just bumping me in the thigh. But from my view, I could clearly see what she was really doing to me. Alexis had skillfully slid her right foot between my body and my hardened member. What looked like an innocent nudge to Jenna, was actually Alexis running the ball of her lovely soft foot from my tender head and down the length of my engorged shaft. Her slow deliberate motion was driving me into a frenzy and I’m sure this teen goddess fully knew was she was doing to me.

It was difficult to concentrate on backing up and it took me much longer then it would have if Alexis hadn’t been teasing me with her foot. I did my best to hold out against her attempts to drive me insane, but the view of her cute little foot doing a number on my manhood, was more than I could take and I started to feel my body tremble. I was on the verge of climaxing and if she didn’t let up soon, there’d be no turning back.

Suddenly, Jenna said, “That’s fine right there, I can reach now.” With that, Alexis stopped her pumping action on my member. With her foot still on the base of my shaft, she slowly slid her foot straight down my leg, forcing my throbbing member to point straight toward the ground. The strain on my manhood was incredible, as it fought against her foot to resume its natural position. She held it there for a few seconds, then quickly removed her foot and placed it on my back next to her other one. This caused my penis to snap back up against my body and then bounce around freely inside my loose sweat pants. I felt relieved and frustrated at the same time. Alexis had taken me to the edge of ecstasy and then just left me hanging, literally. But at the same time, the idea of her making me climax in front of her mom, would have been just too embarrassing to take, let alone explain. It was a win/lose situation. Now that I was close enough, Jenna lifted up her lovely feet and rested them on my back like Alexis had.

“Oh, that’s much more relaxing,” Jenna said. “I wish you would have offered to do this earlier.”

“Um… sorry, I guess I wasn’t thinking?” was all I could stammer out. I was getting used to Alexis treating me as an inanimate object, but I wasn’t expecting it from Jenna.

“You know, I think we would need a longer coffee table than this,” Jenna said. “With our feet up, there isn’t enough room for us to put our drinks.”

“I have an idea, put your head out straight, so we can see what a longer table would be like,” Alexis said, as she removed her left foot from my back, placed it under my face and started lifting my head up. Once my head was parallel with my back, Alexis then placed her right foot on my neck and her left foot on the back of my head.

“Good thinking, that’s much better now,” Jenna said. “Oops, I almost forgot why you sat on the floor in the first place. You better turn your head toward us, so you can see both of us while we’re talking.”

Damn, my own lie came back to bite me. It was hard enough just trying to support both of Alexis’ lovely feet, but now I had to twist my neck in an awkward position as well. I turned my head to the left and back, which now put the heel and arch of Alexis’ right foot against my mouth, and the heel of her left foot just above my left eye.

From this new position, I could now see both of my tormentresses smiling down at me. I now also had Alexis’s perfect little foot right under my nose. I breathed in deeply her heavenly scent and once again felt a stirring in my manhood. Despite the intense strain on my neck muscles, having Alexis’s cute feet on my face, and fragrant scent filling my lungs, gave me the strength to go on. Alexis and Jenna then continued their conversation, almost as if I wasn’t even there. As Alexis got more comfortable, she slid her right foot down a little until the ball of her foot was resting on my cheek. Without my neck to help support the weight of her foot and leg, I now had to double my efforts to keep my head up. I gave a pleading look up at Alexis, but she just smiled back down at me and licked her lips.

I knew exactly what she was hinting at. I slightly opened my mouth and started gently caressing the supple arch of her right foot with my tongue. At first I slowly ran my tongue up and down her arch, then I started making small circular motions. When I looked back up at Alexis, she now had a big satisfying smile. My eyes were transfixed on her deep blue eyes and the beautiful smile that I had brought to her face.

She then laid back a little to get more comfortable, and so that I could get a better angle on the arch of her right foot. As she did this, she also repositioned her left foot. She lifted her left leg, stretched it out a little, and then carelessly brought her heel down to rest on the side of my nose and my left eye socket. Unfortunately for me, I was so wrapped up in watching the pleasure on her face, that I didn’t see it coming, and her bare heel came to rest on my open left eye.

Luckily most of her foot’s weight was on my nose, but my eye was still trapped open and pressed against her heel. As hard as I tried, there was no way I could close it. The saltiness of her heel caused an intense stinging in my eye, and my eyes started to tear up. The pain of her heel in my eye grew more intense with each second, and in spite of the fact I could just turn my head to relieve the pain, I held fast for fear of letting this teen goddess down.

Alexis noticed that I had stopped licking her arch and taped the ball of her right foot on my cheek to get me working again. The tapping of her foot caused my head to shake and the heel of her left foot to grind into my left open eye. This caused fresh almost unbearable pain in my eye. Not wanting her to continue shaking my head, I slowly started licking her arch again. Somehow, in spite of the great pain I was in, the feel of her soft arch against my wanting tongue caused a stiffening of my member, and it wasn’t long before I was at full mast again.

At this point, I was no longer paying any attention to what they were talking about. All my attention was fully focused on pleasuring Alexis’s foot and trying to stay as still as possible. For the slightest movement of Alexis or me, would bring intense pain to my eye. Then as suddenly as it entered my eye, her heel was gone and both her feet were off me. I then noticed Jenna’s feet were no longer on me either, and I collapsed to the ground rolling onto my back in total exhaustion at Alexis’s feet.

“Hello down there,” Alexis said, as she placed her feet on my stomach. “I guess you weren’t paying attention, my mom asked if you’d like to join us in the dining room for some ice cream?”

I slowly looked up at Alexis with tears still in my eyes and blurry vision. She seemed to be looking down at me with a satisfied smile. Almost as if she knew what she had put me through, and what I had endured for her under her cruel little feet. All I could do was give her a little nod yes.

“Hey mom, make that three bowls,” Alexis called out.

“OK, but let’s eat in the dining room, I’d hate to have any get spilled on the carpet our first day here,” Jenna replied.

“Come on let’s go, we don’t want to keep mom waiting,” Alexis said, as lifted her right foot, placed it on my still hard member, and started nudging me. “I see I haven’t worn you out too much yet,” she said with a grin. “So you better get going, unless you want mom to catch you like this.”

That was the last thing I’d want to happen. There was no way I could explain my way out of having a big tent in my pants, so I rolled back over onto all fours. Too worn out to stand, I crawled behind Alexis, as she led me into the dining room. It took a lot of effort in my current state to follow her, but watching her every footfall spurred me on, like dangling a carrot in front of a horse. As we entered the room, Jenna was already placing the bowls on the table, and gave us a curious look.

Alexis noticed this too and said, “Not only is he a great helper, but he makes a good pet too.” She then started clapping her hands and saying in a playful voice, “Here boy, come on boy, that’s a good boy.”

My face turned bright red. OMG, how embarrassing, first I’m furniture, now I’m her pet? But I guess it was just quick thinking on her part to explain why I was crawling behind her.

Jenna just started laughing and said, “You two are so silly, now let’s sit and eat our ice cream before it all melts.”

“Sit where mom?” Alexis asked.

“Crap, that’s right, we were going to bring the kitchen chairs over in the Jimmy tomorrow. I guess we’ll just have to make do?”

Jenna then grabbed the end table that they had used earlier to eat on, and moved it to the head of the table and sat down. Alexis glanced around the room and noticed the box I had carried in for her before. She slid it to the side of the table and took a seat on it. Wanting to sit and rest as soon as possible. I just crawled to the opposite side of the table from Alexis with Jenna on my right, and took a seat on the floor. This now gave me a great under the table view of both their lovely feet.

I took my bowl from the table, set it in my lap, and started eating. I hadn’t even gotten a second bite, when I noticed Alexis’s cute little right foot moving under the table as if searching for something. Her foot found my knee, and then she ran it up my leg and to the edge of my bowl. The next thing I knew, she had stuck her big toe into my bowl of ice cream. I stared mesmerized, as she poked her perfect toe in and out of my food. She then started to slowly move her toe around in my bowl as if stirring it for me. I now felt another kind of stirring as well in my manhood, and I was rock hard yet again at the feet of this teen goddess.

“This just won’t do,” Jenna said. “It’s hard to talk to you when you’re sitting on the floor. I can’t even see your face. Why don’t you put your bowl back on the table and get up on your knees so you can eat with us properly.”

“Yeah, that’s a good idea mom. Our new house slave should be on his knees when he’s eating with us,” Alexis said while laughing.

“Alexis, you’re too much,” Jenna replied, as she joined in laughing with Alexis. My face went beet red. Alexis really seemed to be getting a kick out of humiliating me in front of her mom and I wondered just how far she would go before the night was through. I also wondered exactly what she wanted me to do next. They both had told me to get up on my knees, yet Alexis still hadn’t removed her big toe from my bowl. Suddenly I heard a clinking noise across from me.

“Damn, I dropped my spoon,” Alexis said. “Could you be a dear and get it for me while mom goes and gets me a clean one?”

She then removed her toe from my bowl and crossed her right leg over her left. Jenna then got up to get Alexis a new spoon, as I put my bowl on the table and I crawled under it to get the one she’d dropped. As soon as I went under, I saw Alexis’s beautiful face looking under the table at me.

“Oh, and could you clean up the mess too while your down there?” Alexis asked, as she motioned for me to open my mouth.

As soon as I did, she stuck her sweet ice cream covered big toe in my mouth and I sucked on it for all I was worth. I swirled my tongue all around her perfect toe, not wanting to miss even the slightest bit. It was definitely the best tasting ice cream I had ever had. Suddenly I saw Jenna’s lovely socked feet pass underneath me. I had been so wrapped up on sucking Alexis’s big toe that I hadn’t even noticed her come back and sit down. Alexis could see her coming, but had made no attempt to warn me, or to remove her toe from my mouth. Hopefully I was far enough under the table that Jenna couldn’t see Alexis’s toe in my mouth. “Oh, here’s a damp cloth for you to clean the floor with while you’re down there,” Jenna said as she tossed the towel under the table. “I don’t want the tile floor to be all sticky.”

As I reached for the towel, Alexis was still watching me, and she shook her head no. She slowly dragged her perfect big toe across my tongue and removed it from my mouth. She then used it to point to the spot on the floor, which was mere inches from where Jenna’s lovely sock covered feet now were. Once again, I knew what she wanted me to do, and slowly lowered my head to the floor, trying my best not to bump into Jenna’s feet. As I started licking the mess off the tile floor, Jenna’s pretty sock covered feet were right in my face. Although I’d had Alexis’s cute little feet in my face before, this was the first time I was ever this close to Jenna’s lovely feet. I thought back to when we were setting her bed up, and how I longed to put my face in her socked soles. So I paused for a moment, turned my head to the right, and got my nose as close to the soles her socked feet as possible. I then inhaled slowly and deeply, trying to take in as much of Jenna’s sweet foot scent that I could. Her scent was slightly stronger than Alexis’s, probably due to the fact that she was wearing socks. The more I took in, the more I wanted, and my member was soon rock hard again. I was lost in foot sniffing bliss, and if Jenna didn’t have socks on, I’m sure she could have felt it.

“You’re never going to get the floor cleaned that way,” Alexis whispered above me.

OMG, I was so drawn in by Jenna’s lovely socked foot scent, that it slipped my mind that Alexis had been watching me the whole time. Alexis had put me into positions like this before, but this was the first time I was doing it of my own accord, and she just caught me. I was mortified. I couldn’t even look up at her. I quickly licked up the rest of the mess on the floor, and crawled out from under the table. Once I was out, I got to my knees next to the table and tried to just eat my ice cream as if nothing had happened.

“Why is your face so red?” Jenna asked.

“Um. I guess it’s just from getting up so quickly,” I stammered out.

“That’s possible,” Alexis replied. “But it’s more likely because I just caught you smelling my mom’s feet.”

OMG, I can’t believe she just told Jenna what she had seen me doing under the table. At first I thought she was going to go along with my excuse, but instead she used it to humiliate me even further in front of Jenna. I could feel my face get even more flush, and my jaw dropped open in disbelief of what I just heard. After a moment of awkward silence, they both busted out laughing.

“Damn you’re on a roll tonight girl,” Jenna said with amusement in her voice, “my stomach’s starting to hurt from all this laughing.”

Thank goodness Jenna thought Alexis was only fooling around, there would have been no way to explain my way out of that one. After the laughing died down, we all went back to eating our ice cream and just chit chatting. But it wasn’t long before I felt something brush against my leg. As I looked down, I saw Alexis’s cute little foot work its way to my groin. She slowly started rubbing the ball of her foot up and down my manhood. Once I was hard enough, she then took advantage of the thin sweat pants I had on, and manipulated my member between her big toe and the one next to it. She then worked it up and down my throbbing shaft, and I was at full mast in a matter of seconds.

Alexis finished her bowl first and sat back to relax a little. She could now give her full attention to watching me squirm at her naughty feet. Her actions made it hard for me to concentrate on eating, and my hand was already trembling as I tried to put food in my mouth. What made it worse, was as I ate, I couldn’t help but think how not long ago, that same toe was swirling around in my food.

As her cute little right foot was driving me crazy, she suddenly brought the heel of her cruel left foot down atop the head of my shaft to rest. This brought a lot pressure to my throbbing manhood, but somehow seemed to also enhance the experience. About this time, Jenna finished her bowl too, and sat back and stretched her legs out. As she did, I felt her legs bump up against Alexis.

“Hey, how did you get your feet up like that?” Jenna asked.

“Oh, I just hooked my heel on the waistband of his sweat pants,” Alexis replied.

“He doesn’t mind, do you?”

Alexis had me so worked up, all I could do was shake my head no. “That’s not fair,” Jenna replied back. “I’ve had a hard day too and would like to put my feet up as well.”

“Well then just put your legs to rest across mine, it should be strong enough to support both of us.”

Jenna lifted her left leg and placed her ankle across Alexis’s left ankle. She then lifted her right leg and crossed it at the ankle as well. This simple action just tripled the weight that my head and shaft had to support. “Ah, that’s much better,” Jenna said, “and his waistband is supporting the weight of our legs just fine.”

My waistband? If she only knew how I now suffered just to make her more comfortable. The added weight was now driving the heel of Alexis’s cruel little foot into the head of my manhood. I could feel the extra weight all the way down my shaft to the base, and my groin muscles strained to support them. It felt as if the weight was going to cause my manhood to pull loose from my body at any second. If only I could make my member soft again, then they’d have nothing to rest their lovely feet on. But Alexis’s skillful little right foot kept working up and down my shaft, making sure that wouldn’t happen.

Suddenly Jenna started to sway her lovely right foot. I could feel her soft socked foot caressing the front of my body, and this turned me on even more. Unfortunately, this motion also traveled down to Alexis’s foot as well. The heel of her cruel little left foot was now grinding into my head, like she was trying to put out a cigarette. I felt a huge mix of emotions. Part of me couldn’t take much more of this abuse on my manhood and wanted it to end. But a larger part of me would take whatever punishment they’d dish out to be at the feet of these beautiful tormentresses.

Alexis started to pick up the pace and she was now quickly running her naughtily little right foot along my shaft. My mind went into the zone, and I couldn’t help but look to watch what their lovely feet were doing to me. There in my lap, were four of the most perfect feet I had ever seen. Jenna’s soft sock covered foot was brushing back and forth across my body. Alexis’s cute little foot was expertly manipulating my member between her two toes. And the weight of three of their lovely feet was crushing into my member.

The sight of what they were doing to me was more than I could take in my current worked up condition, and I felt my whole body start to tremble again. No, not here, not now, not right in front of her mom. I looked up and gave Alexis a pleading glance, but once again that evil grin was on her face and she just continued to pump away on my shaft.

Damn, if only I wouldn’t have looked down, maybe I could have held out. But there was no turning back now, so once again I looked back down to watch. Alexis, sensing I was close to climaxing, started to purposely sway her cruel left foot, in order to grind her heel harder into the head of my cock. My body tensed up as she brought fresh sensations of pain to my already abused head. I could feel my heads hole being opened and closed, and twisted in all kinds of unnatural ways against my sweats and her cruel heel.

In spite of the punishment my manhood was taking, I could feel that I was close to having an orgasm. Alexis now bore down hard with her toes on my shaft and started to violently stoke my cock. The pain, the pressure, the sight, and attention from her naughty right foot, was all more than I could take, and I could feel myself start to cum at their beautiful feet. But her cruel left heel was still blocking its exit, and I could feel the pressure mounting, until I finally felt my cum spraying out from under her heel and all over the front of my body and sweat pants. I reeled in ecstasy as Alexis continued pumping my manhood in an attempt to get every last drop out.

Luckily I was kneeling in front of the table, because I was so drained from the experience that I slumped forward against it. Alexis, realizing that my manhood would soon be too soft to support their legs, removed her left foot. Being that Jenna’s legs were on top of hers, she had no choice but to put her feet down as well.

“Well I guess we’ve taken a long enough break,” Jenna said. “I’ll just take these empty dishes to the sink and deal with them later.” Then noticing that I hadn’t finished yet, she added, “Hurry up and finish that and bring yours in too when you’re done.”

Once Jenna left the room, I sat back on my heels to rest. I glanced down and saw the front of my sweat pants were soaked with cum. How in the world am I going to explain the mess in my pants to Jenna? I looked back up at Alexis, who upon seeing my predicament, just smiled down and giggled. I guess I was on my own this time. As I heard Jenna heading back to the dining room, an idea hit me. I took my bowl from the table, and poured what was left of my melted ice cream into my lap. Seeing this, Alexis burst out laughing.

“What did I miss?” Jenna asked as she reentered the room.

“He tried to hurry up and drink the last of his ice cream before you got back and spilled it all over himself.”

Jenna seeing my lap covered in melted ice cream broke out laughing as well. “Well, I guess I better just go home and clean up, I’ll see you two tomorrow then,” I said.

“No, you can’t leave yet. You still have to help Alexis set up her bed, so she has a place to sleep tonight,” Jenna replied. “Alexis, since you two have to go there anyway, take him up to your room and see if you can’t find a pair of your sweats for him to wear for now.”

Alexis then got up from the table and headed upstairs, with me following close behind.
